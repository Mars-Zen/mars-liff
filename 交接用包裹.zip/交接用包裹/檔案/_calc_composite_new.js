// ── 取兩人本命盤資料 ──────────────────────────────────────────
const natalA = $('Call_Natal_A').first().json.natal;
const natalB = $json.natal;
const prepData = $('Prepare_All').first().json;

// ── 星座定義 ─────────────────────────────────────────────────
const SIGNS = [
  {en:'Aries',zh:'牡羊',el:'Fire'},{en:'Taurus',zh:'金牛',el:'Earth'},
  {en:'Gemini',zh:'雙子',el:'Air'},{en:'Cancer',zh:'巨蟹',el:'Water'},
  {en:'Leo',zh:'獅子',el:'Fire'},{en:'Virgo',zh:'處女',el:'Earth'},
  {en:'Libra',zh:'天秤',el:'Air'},{en:'Scorpio',zh:'天蠍',el:'Water'},
  {en:'Sagittarius',zh:'射手',el:'Fire'},{en:'Capricorn',zh:'摩羯',el:'Earth'},
  {en:'Aquarius',zh:'水瓶',el:'Air'},{en:'Pisces',zh:'雙魚',el:'Water'}
];

function lonToSign(lon) {
  const idx = Math.floor(((lon % 360) + 360) % 360 / 30) % 12;
  return { ...SIGNS[idx], deg: parseFloat((((lon % 30) + 30) % 30).toFixed(2)) };
}
function midpoint(lonA, lonB) {
  let diff = Math.abs(lonA - lonB);
  let mid = (lonA + lonB) / 2;
  if (diff > 180) mid = (mid + 180) % 360;
  return ((mid % 360) + 360) % 360;
}
function normalizeObjs(raw) {
  if (!raw) return {};
  if (Array.isArray(raw)) { const r = {}; for (const p of raw) { if (p.name) r[p.name] = p; } return r; }
  return raw;
}
function clamp(v, lo, hi) { return Math.min(hi, Math.max(lo, v)); }

const objectsA = normalizeObjs(natalA?._objects || natalA?.objects || natalA?.planets || natalA?.bodies || natalA || {});
const objectsB = normalizeObjs(natalB?._objects || natalB?.objects || natalB?.planets || natalB?.bodies || natalB || {});

const PLANET_DEFS = {
  Sun:     {key:'4000001', alt:['Sun','SUN','sun','0']},
  Moon:    {key:'4000002', alt:['Moon','MOON','moon','1']},
  Mercury: {key:'4000003', alt:['Mercury','MERCURY','mercury','2']},
  Venus:   {key:'4000004', alt:['Venus','VENUS','venus','3']},
  Mars:    {key:'4000006', alt:['Mars','MARS','mars','4']},
  Jupiter: {key:'4000007', alt:['Jupiter','JUPITER','jupiter','5']},
  Saturn:  {key:'4000008', alt:['Saturn','SATURN','saturn','6']},
  Asc:     {key:'3000001', alt:['Asc','ASC','Ascendant','ascendant']}
};

function findObj(objects, def) {
  if (objects[def.key] != null) return objects[def.key];
  for (const n of def.alt) {
    if (objects[n] != null) return objects[n];
    const lower = n.toLowerCase();
    if (objects[lower] != null) return objects[lower];
  }
  return null;
}
function getLon(objects, def) {
  const obj = findObj(objects, def);
  if (!obj) return null;
  return obj?.longitude?.raw ?? obj?.lon ?? obj?.lng ?? obj?.abs_pos ?? obj?.position ?? null;
}

// ── 合盤計算（取中點）─────────────────────────────────────────
const composite = {};
const composite_lon = {};
for (const [name, def] of Object.entries(PLANET_DEFS)) {
  const lonA = getLon(objectsA, def);
  const lonB = getLon(objectsB, def);
  if (lonA == null || lonB == null) continue;
  const mid = midpoint(lonA, lonB);
  composite[name] = { name, longitude: parseFloat(mid.toFixed(3)), ...lonToSign(mid) };
  composite_lon[name] = mid;
}
const hasP = k => composite[k] != null;

// ════════════════════════════════════════════════════════════
// LAYER 1：Sign 落座分數表（星座 → 各維度基礎分）
// ════════════════════════════════════════════════════════════

// ── 吸引（金星×50% + 火星×50%）──
// Mars 主宰=天蠍/牡羊, 旺=摩羯, 弱=天秤/金牛, 陷=巨蟹
const ATTR_MARS = {
  Scorpio:92, Aries:88, Capricorn:75, Leo:72, Sagittarius:65,
  Gemini:58, Pisces:52, Aquarius:45, Libra:40, Virgo:28, Taurus:35, Cancer:25
};
// Venus 主宰=天秤/金牛, 旺=雙魚, 弱=天蠍/牡羊, 陷=處女
const ATTR_VEN = {
  Libra:95, Taurus:88, Pisces:83, Leo:68, Gemini:60, Cancer:56,
  Sagittarius:55, Aquarius:48, Capricorn:38, Virgo:30, Aries:40, Scorpio:38
};
// Moon 主宰=巨蟹, 旺=金牛, 弱=摩羯, 陷=天蠍
const ATTR_MOO = {
  Cancer:85, Taurus:82, Pisces:72, Leo:60, Libra:58, Scorpio:58,
  Sagittarius:50, Aries:52, Gemini:48, Aquarius:42, Capricorn:28, Virgo:22
};

// ── 穩定（月亮×45% + 土星×55%）──
// Moon 主宰=巨蟹, 旺=金牛, 弱=摩羯, 陷=天蠍
const STAB_MOO = {
  Taurus:95, Cancer:85, Virgo:72, Pisces:55, Libra:52,
  Aquarius:45, Leo:40, Gemini:38, Sagittarius:28, Scorpio:32, Capricorn:25, Aries:18
};
// Saturn 主宰=摩羯/水瓶, 旺=天秤, 弱=巨蟹/獅子, 陷=牡羊
const STAB_SAT = {
  Capricorn:95, Libra:90, Aquarius:80, Taurus:70, Virgo:62, Scorpio:60,
  Pisces:48, Gemini:42, Sagittarius:35, Leo:28, Cancer:20, Aries:15
};
// Sun 主宰=獅子, 旺=牡羊, 弱=水瓶, 陷=天秤
const STAB_SUN = {
  Leo:85, Aries:78, Capricorn:75, Taurus:68, Cancer:65, Virgo:62,
  Scorpio:58, Pisces:46, Sagittarius:42, Gemini:38, Aquarius:28, Libra:22
};

// ── 溝通（水星×60% + 上升×40%）──
// Mercury 主宰=雙子/處女, 旺=處女, 弱=射手/雙魚, 陷=雙魚
const COMM_MER = {
  Gemini:96, Virgo:90, Aquarius:72, Libra:68, Aries:62, Leo:58,
  Scorpio:52, Cancer:48, Taurus:42, Capricorn:38, Pisces:22, Sagittarius:18
};
// ASC 無尊位，依溝通親和度（風>火>水>土）
const COMM_ASC = {
  Gemini:92, Libra:84, Aquarius:78, Leo:66, Sagittarius:62, Aries:56,
  Scorpio:48, Cancer:42, Pisces:42, Virgo:35, Taurus:30, Capricorn:20
};
// Sun 主宰=獅子, 旺=牡羊, 弱=水瓶, 陷=天秤
const COMM_SUN = {
  Gemini:90, Leo:82, Aries:76, Aquarius:72, Sagittarius:68, Scorpio:55,
  Virgo:50, Cancer:44, Taurus:38, Pisces:38, Libra:32, Capricorn:28
};

// ── 信任（月亮×35% + 太陽×40% + 土星×25%）──
// Moon 主宰=巨蟹, 旺=金牛, 弱=摩羯, 陷=天蠍
const TRST_MOO = {
  Cancer:95, Taurus:90, Pisces:65, Virgo:62, Libra:55,
  Leo:50, Scorpio:48, Aquarius:42, Gemini:36, Capricorn:25, Sagittarius:30, Aries:18
};
// Saturn 主宰=摩羯/水瓶, 旺=天秤, 弱=巨蟹/獅子, 陷=牡羊
const TRST_SAT = {
  Capricorn:95, Libra:88, Aquarius:80, Taurus:68, Virgo:62, Scorpio:58,
  Pisces:48, Gemini:42, Sagittarius:35, Leo:28, Cancer:20, Aries:15
};
// Sun 主宰=獅子, 旺=牡羊, 弱=水瓶, 陷=天秤
const TRST_SUN = {
  Leo:90, Taurus:88, Capricorn:85, Scorpio:82,
  Cancer:75, Aries:70, Virgo:65,
  Sagittarius:52, Pisces:46, Aquarius:35, Gemini:31, Libra:27
};

// ── 成長（木星×45% + 太陽×35% + 上升×20%）──
// Jupiter 主宰=射手/雙魚, 旺=巨蟹, 弱=雙子/處女, 陷=摩羯
const GROW_JUP = {
  Sagittarius:95, Cancer:88, Pisces:84, Aries:70, Leo:66, Aquarius:62,
  Libra:55, Scorpio:50, Taurus:48, Capricorn:20, Gemini:18, Virgo:15
};
// Sun 主宰=獅子, 旺=牡羊, 弱=水瓶, 陷=天秤
const GROW_SUN = {
  Sagittarius:90, Aries:84, Leo:80, Gemini:68, Aquarius:55, Scorpio:55,
  Pisces:50, Cancer:48, Capricorn:45, Taurus:38, Libra:28, Virgo:25
};
// ASC 無尊位，依成長親和度（火/風>水>土）
const GROW_ASC = {
  Sagittarius:90, Aries:82, Aquarius:78, Gemini:72, Leo:65, Libra:55,
  Scorpio:52, Pisces:45, Cancer:42, Capricorn:38, Taurus:28, Virgo:18
};

function signScore(table, name) {
  if (!hasP(name)) return 50;
  return table[composite[name].en] ?? 50;
}

// ── Layer 1：Sign 維度基礎分 ──────────────────────────────────
const base_attr  = clamp(signScore(ATTR_VEN,'Venus')*0.50 + signScore(ATTR_MARS,'Mars')*0.50, 0, 100);

const hasSat = hasP('Saturn');
const base_stab = hasSat
  ? clamp(signScore(STAB_MOO,'Moon')*0.40 + signScore(STAB_SAT,'Saturn')*0.40 + signScore(STAB_SUN,'Sun')*0.20, 0, 100)
  : clamp(signScore(STAB_MOO,'Moon')*0.67 + signScore(STAB_SUN,'Sun')*0.33, 0, 100);

const base_comm = clamp(signScore(COMM_MER,'Mercury')*0.60 + signScore(COMM_ASC,'Asc')*0.40, 0, 100);

const base_trst = hasSat
  ? clamp(signScore(TRST_MOO,'Moon')*0.35 + signScore(TRST_SUN,'Sun')*0.40 + signScore(TRST_SAT,'Saturn')*0.25, 0, 100)
  : clamp(signScore(TRST_MOO,'Moon')*0.45 + signScore(TRST_SUN,'Sun')*0.55, 0, 100);

const hasJup = hasP('Jupiter');
const base_grow = hasJup
  ? clamp(signScore(GROW_JUP,'Jupiter')*0.45 + signScore(GROW_SUN,'Sun')*0.35 + signScore(GROW_ASC,'Asc')*0.20, 0, 100)
  : clamp(signScore(GROW_SUN,'Sun')*0.55 + signScore(GROW_ASC,'Asc')*0.45, 0, 100);

// ════════════════════════════════════════════════════════════
// LAYER 2：Aspect 相位倍率（三段 orb）
// ════════════════════════════════════════════════════════════

function getAspect(lon1, lon2) {
  const diff = Math.abs(lon1 - lon2) % 360;
  const angle = diff > 180 ? 360 - diff : diff;
  const ASPECTS = [
    {name:'conjunction', target:0,   orb:8},
    {name:'sextile',     target:60,  orb:6},
    {name:'square',      target:90,  orb:8},
    {name:'trine',       target:120, orb:8},
    {name:'opposition',  target:180, orb:8}
  ];
  for (const asp of ASPECTS) {
    const dist = Math.abs(angle - asp.target);
    if (dist <= asp.orb) return { name: asp.name, dist };
  }
  return null;
}

// orb強度：0-3°=1.0, 3-6°=0.6, 6-8°=0.3
function orbStrength(dist) {
  if (dist <= 3) return 1.0;
  if (dist <= 6) return 0.6;
  return 0.3;
}

// multiplier表（合相/六分/四分/三分/對分）
function applyAspect(lon1, lon2, mults) {
  if (lon1 == null || lon2 == null) return 1.0;
  const asp = getAspect(lon1, lon2);
  if (!asp) return 1.0;
  const full = mults[asp.name] ?? 1.0;
  const strength = orbStrength(asp.dist);
  return 1.0 + (full - 1.0) * strength;
}

// 吸引 primary: Venus↔Mars, secondary: Moon↔Venus
const AM_VENUS_MARS = {conjunction:1.10, trine:1.07, sextile:1.04, opposition:0.99, square:0.94};
const AM_MOON_VENUS = {conjunction:1.05, trine:1.03, sextile:1.02, opposition:0.99, square:0.97};

// 穩定 primary: Moon↔Saturn, secondary: Sun↔Saturn
const AS_MOON_SAT = {conjunction:1.09, trine:1.07, sextile:1.04, opposition:0.94, square:0.91};
const AS_SUN_SAT  = {conjunction:1.06, trine:1.04, sextile:1.02, opposition:0.96, square:0.95};

// 溝通 primary: Mercury↔Asc, secondary: Mercury↔Sun
const AC_MER_ASC = {conjunction:1.08, trine:1.05, sextile:1.03, opposition:0.95, square:0.92};
const AC_MER_SUN = {conjunction:1.06, trine:1.04, sextile:1.02, opposition:0.97, square:0.96};

// 信任 primary: Sun↔Moon, secondary: Moon↔Saturn
const AT_SUN_MOO = {conjunction:1.09, trine:1.07, sextile:1.04, opposition:0.96, square:0.93};
const AT_MOO_SAT = {conjunction:1.07, trine:1.05, sextile:1.03, opposition:0.93, square:0.91};

// 成長 primary: Jupiter↔Sun, secondary: Jupiter↔Asc, tertiary: Sun↔Asc
const AG_JUP_SUN = {conjunction:1.10, trine:1.08, sextile:1.05, opposition:0.97, square:0.93};
const AG_JUP_ASC = {conjunction:1.06, trine:1.04, sextile:1.02, opposition:0.98, square:0.95};
const AG_SUN_ASC = {conjunction:1.06, trine:1.04, sextile:1.02, opposition:0.97, square:0.94};

// 穩定 tertiary: Moon↔Sun
const AS_MOO_SUN = {conjunction:1.07, trine:1.05, sextile:1.03, opposition:0.96, square:0.93};

// 信任 tertiary: Sun↔Saturn
const AT_SUN_SAT = {conjunction:1.07, trine:1.05, sextile:1.03, opposition:0.96, square:0.93};

const L = composite_lon;

const asp_attr  = clamp(
  applyAspect(L.Venus,   L.Mars,    AM_VENUS_MARS) *
  applyAspect(L.Moon,    L.Venus,   AM_MOON_VENUS),
  0.82, 1.18);

const asp_stab  = clamp(
  applyAspect(L.Moon,    L.Saturn,  AS_MOON_SAT) *
  applyAspect(L.Sun,     L.Saturn,  AS_SUN_SAT)  *
  applyAspect(L.Moon,    L.Sun,     AS_MOO_SUN),
  0.75, 1.25);

const asp_comm  = clamp(
  applyAspect(L.Mercury, L.Asc,     AC_MER_ASC) *
  applyAspect(L.Mercury, L.Sun,     AC_MER_SUN),
  0.82, 1.18);

const asp_trst  = clamp(
  applyAspect(L.Sun,     L.Moon,    AT_SUN_MOO) *
  applyAspect(L.Moon,    L.Saturn,  AT_MOO_SAT) *
  applyAspect(L.Sun,     L.Saturn,  AT_SUN_SAT),
  0.75, 1.25);

const asp_grow  = clamp(
  applyAspect(L.Jupiter, L.Sun,     AG_JUP_SUN) *
  applyAspect(L.Jupiter, L.Asc,     AG_JUP_ASC) *
  applyAspect(L.Sun,     L.Asc,     AG_SUN_ASC),
  0.75, 1.25);


// ════════════════════════════════════════════════════════════
// LAYER 3：Element Balance（整體元素氣候，線性漸進倍率）
// ════════════════════════════════════════════════════════════

// 計算 elem_pct（8個合盤點：Sun Moon Mercury Venus Mars Jupiter Saturn Asc）
const elemCount = {Fire:0, Earth:0, Air:0, Water:0};
for (const k of ['Sun','Moon','Mercury','Venus','Mars','Jupiter','Saturn','Asc']) {
  const el = composite[k]?.el;
  if (el && elemCount[el] != null) elemCount[el]++;
}
const et = Object.values(elemCount).reduce((a,b)=>a+b,0) || 1;
const elemPct = {};
for (const [k,v] of Object.entries(elemCount)) elemPct[k] = parseFloat((v/et).toFixed(3));

// 找主導元素
const dominantElem = Object.entries(elemPct).sort((a,b)=>b[1]-a[1])[0];
const domEl   = dominantElem[0];
const domPct  = dominantElem[1];

// 線性漸進強度：30%=0, 50%=1.0（clamp 0~1）
const elemStrength = clamp((domPct - 0.30) / 0.20, 0, 1);

// 元素倍率表（>50% 全效，30%~50% 線性）
const ELEM_FULL = {
  Fire:  {attr:1.03, stab:0.97, comm:1.01, trst:0.98, grow:1.02},
  Earth: {attr:1.00, stab:1.03, comm:0.98, trst:1.01, grow:0.97},
  Air:   {attr:1.01, stab:1.00, comm:1.03, trst:0.97, grow:1.01},
  Water: {attr:1.01, stab:1.01, comm:0.97, trst:1.03, grow:0.98}
};

function elemMult(dim) {
  const full = ELEM_FULL[domEl]?.[dim] ?? 1.0;
  return 1.0 + (full - 1.0) * elemStrength;
}

// ── 三層合一最終分數（sign × aspect × element，一次 clamp）────
const attraction    = Math.round(clamp(base_attr * asp_attr * elemMult('attr'), 0, 100));
const stability     = Math.round(clamp(base_stab * asp_stab * elemMult('stab'), 0, 100));
const communication = Math.round(clamp(base_comm * asp_comm * elemMult('comm'), 0, 100));
const trust         = Math.round(clamp(base_trst * asp_trst * elemMult('trst'), 0, 100));
const growth        = Math.round(clamp(base_grow * asp_grow * elemMult('grow'),  0, 100));

// ── 契合度（加權平均 → 分段曲線映射）──
// CURVE 以 50k 次 Monte Carlo 百分位數對齊目標分布（85+≈4%，35-≈6%，中心≈60）
const rawCompat = (attraction + stability + communication + trust + growth) * 0.20;
function curveScore(r) {
  const C = [
    [26,20],[33,25],[37,30],[40,35],[43,40],[47,45],
    [50,50],[53,55],[56,60],[60,65],[63,70],[67,75],
    [71,80],[75,85],[80,90],[89,95]
  ];
  if (r <= C[0][0]) return C[0][1];
  if (r >= C[C.length-1][0]) return C[C.length-1][1];
  for (let i = 0; i < C.length-1; i++) {
    if (r >= C[i][0] && r <= C[i+1][0]) {
      const t = (r - C[i][0]) / (C[i+1][0] - C[i][0]);
      return Math.round(C[i][1] + t * (C[i+1][1] - C[i][1]));
    }
  }
  return Math.round(r);
}
const compatScore = clamp(curveScore(rawCompat), 20, 95);

// ── 元素百分比（整數，總和保證=100，最大餘數法）────────────
const elemPctDisplay = {};
const _elemRows = ['Fire','Earth','Air','Water'].map(k => {
  const exact = (elemPct[k] || 0) * 100;
  const fl = Math.floor(exact);
  return { k, exact, fl, rem: exact - fl };
});
const _floorSum = _elemRows.reduce((s,o) => s + o.fl, 0);
const _left = Math.round(100 - _floorSum);
_elemRows.sort((a,b) => (b.rem - a.rem) || (b.exact - a.exact));
_elemRows.forEach((o,i) => { elemPctDisplay[o.k] = o.fl + (i < _left ? 1 : 0); });

// ── 關係類型（合盤太陽元素 × 合盤月亮元素 × 契合度分段）──
const sunEl  = composite['Sun']?.el  || 'Fire';
const moonEl = composite['Moon']?.el || 'Water';
const relTier = compatScore >= 70 ? 'H' : compatScore >= 45 ? 'M' : 'L';
const REL_TYPES = {
  'Fire-Fire-H'   :'說走就走的熱血搭檔',
  'Fire-Fire-M'   :'相處充滿活力但衝突來得快',
  'Fire-Fire-L'   :'熱度有了但耐心不夠',
  'Fire-Earth-H'  :'有衝勁又有安全感的組合',
  'Fire-Earth-M'  :'一個往前衝一個穩住的平衡搭檔',
  'Fire-Earth-L'  :'步調差太多容易互相消耗',
  'Fire-Air-H'    :'充滿新鮮感停不下來的搭檔',
  'Fire-Air-M'    :'相處愉快有趣但缺少踏實感',
  'Fire-Air-L'    :'都在動卻背道而馳難以同行',
  'Fire-Water-H'  :'一起向前走也懂得照顧彼此感受',
  'Fire-Water-M'  :'有主動性也有體貼感的搭檔',
  'Fire-Water-L'  :'行動派遇上感受派難以同頻',
  'Earth-Fire-H'  :'踏實可靠又有溫度的搭檔',
  'Earth-Fire-M'  :'有依靠感但情緒起伏難預期',
  'Earth-Fire-L'  :'有安全感但情緒起伏破壞默契',
  'Earth-Earth-H' :'不需多說也能互相依靠的組合',
  'Earth-Earth-M' :'很安穩但有時需要一點刺激',
  'Earth-Earth-L' :'各自守著自己難以有突破',
  'Earth-Air-H'   :'有安全感又不會感到悶的組合',
  'Earth-Air-M'   :'踏實生活中也保有彼此自由',
  'Earth-Air-L'   :'生活重心不同難以真正交集',
  'Earth-Water-H' :'踏實相守又懂照顧彼此感受',
  'Earth-Water-M' :'互相照顧有依靠的日常搭檔',
  'Earth-Water-L' :'想踏實相處但情緒常打亂節奏',
  'Air-Fire-H'    :'有話聊有熱情又能互相點燃',
  'Air-Fire-M'    :'相處熱鬧但少了靜下來的默契',
  'Air-Fire-L'    :'熱鬧歸熱鬧但難有共同目標',
  'Air-Earth-H'   :'想法多又能踏實在一起的組合',
  'Air-Earth-M'   :'想法很多但有時難以落實',
  'Air-Earth-L'   :'說得多做得少難以真正落地',
  'Air-Air-H'     :'話題永遠聊不完的心靈知音',
  'Air-Air-M'     :'話說得開心但少了那份踏實感',
  'Air-Air-L'     :'話投機但難以真正深入彼此',
  'Air-Water-H'   :'話說得來又懂得傾聽對方',
  'Air-Water-M'   :'聊得很開心但不一定真的懂對方',
  'Air-Water-L'   :'說得夠多但始終說不進彼此心裡',
  'Water-Fire-H'  :'感受細膩又充滿熱情的組合',
  'Water-Fire-M'  :'有豐富感受也有熱情的搭檔',
  'Water-Fire-L'  :'太投入容易互相拖進情緒裡',
  'Water-Earth-H' :'細膩體貼又踏實可依靠的組合',
  'Water-Earth-M' :'彼此都很在意對方的組合',
  'Water-Earth-L' :'越想靠近越發現現實難以配合',
  'Water-Air-H'   :'直覺相通相處又輕鬆的知音',
  'Water-Air-M'   :'相處自在也有彼此感受的搭檔',
  'Water-Air-L'   :'一方渴望靠近一方習慣保持空間',
  'Water-Water-H' :'不用多說就能懂彼此的知音',
  'Water-Water-M' :'彼此感受相通的深度組合',
  'Water-Water-L' :'彼此都很敏感容易陷入情緒內耗',
};
const relType = REL_TYPES[`${sunEl}-${moonEl}-${relTier}`] || '獨特的星際連結';

return [{
  json: {
    composite,
    scores: {
      attraction:    clamp(curveScore(attraction),    20, 95),
      stability:     clamp(curveScore(stability),     20, 95),
      communication: clamp(curveScore(communication), 20, 95),
      trust:         clamp(curveScore(trust),         20, 95),
      growth:        clamp(curveScore(growth),        20, 95),
    },
    compat_score: compatScore,
    elem_pct: elemPctDisplay,
    relationship_type: relType,
    nickname: prepData.nickname,
    partner_name: prepData.partner_name,
    cache_key: prepData.cache_key,
    user_uid: prepData.user_uid,
    partner_birth_date: prepData.partner_birth_date
  }
}];