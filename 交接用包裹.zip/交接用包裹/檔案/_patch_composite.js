const fs = require('fs');
const jsonPath = 'c:/Users/USER/OneDrive/桌面/全部/API_Composite.json';
const jsPath   = 'c:/Users/USER/OneDrive/桌面/全部/_calc_composite_new.js';
const rawJson  = fs.readFileSync(jsonPath, 'utf8').replace(/^﻿/, '');
const workflow = JSON.parse(rawJson);
const newCode  = fs.readFileSync(jsPath, 'utf8');
let updated = false;
for (const node of workflow.nodes) {
  if (node.name === 'Calc_Composite') {
    node.parameters.jsCode = newCode;
    updated = true;
    break;
  }
}
if (!updated) { console.error('Node not found!'); process.exit(1); }
fs.writeFileSync(jsonPath, JSON.stringify(workflow, null, 2), 'utf8');
const check = JSON.parse(fs.readFileSync(jsonPath, 'utf8'));
const calc  = check.nodes.find(n => n.name === 'Calc_Composite');
const code  = calc.parameters.jsCode;
console.log('AC_MER_ASC    :', code.includes('AC_MER_ASC'));
console.log('AT_SUN_MOO    :', code.includes('AT_SUN_MOO'));
console.log('Mercury<>Asc  :', code.includes('L.Mercury, L.Asc'));
console.log('Sun<>Moon     :', code.includes('L.Sun,     L.Moon'));
console.log('rawCompat     :', code.includes('rawCompat'));
console.log('normalize(60) :', code.includes('rawCompat - 60'));
console.log('AC_MER_MER gone:', !code.includes('AC_MER_MER'));
console.log('AT_MOO_MOO gone:', !code.includes('AT_MOO_MOO'));
console.log('nodes         :', check.nodes.length);
console.log('file bytes    :', fs.statSync(jsonPath).size);