// Monte Carlo 模擬：雙人合盤契合度分布
// 用法：node _simulate_compat.js [次數，預設10000]
// ─────────────────────────────────────────────

const N = parseInt(process.argv[2]) || 10000;

// ── 星座定義 ───────────────────────────────────
const SIGNS = [
  {en:'Aries',zh:'牡羊',el:'Fire'},{en:'Taurus',zh:'金牛',el:'Earth'},
  {en:'Gemini',zh:'雙子',el:'Air'},{en:'Cancer',zh:'巨蟹',el:'Water'},
  {en:'Leo',zh:'獅子',el:'Fire'},{en:'Virgo',zh:'處女',el:'Earth'},
  {en:'Libra',zh:'天秤',el:'Air'},{en:'Scorpio',zh:'天蠍',el:'Water'},
  {en:'Sagittarius',zh:'射手',el:'Fire'},{en:'Capricorn',zh:'摩羯',el:'Earth'},
  {en:'Aquarius',zh:'水瓶',el:'Air'},{en:'Pisces',zh:'雙魚',el:'Water'}
];

function lonToSign(lon) {
  const idx = Math.floor(((lon % 360) + 360) % 360 / 30) % 12;
  return { ...SIGNS[idx] };
}

// ── 分段曲線映射（依分布百分位數對齊目標）──
function curveScore(raw) {
  const CURVE = [
    [26,20],[33,25],[37,30],[40,35],[43,40],[47,45],
    [50,50],[53,55],[56,60],[60,65],[63,70],[67,75],
    [71,80],[75,85],[80,90],[89,95]
  ];
  if (raw <= CURVE[0][0]) return CURVE[0][1];
  if (raw >= CURVE[CURVE.length-1][0]) return CURVE[CURVE.length-1][1];
  for (let i = 0; i < CURVE.length-1; i++) {
    if (raw >= CURVE[i][0] && raw <= CURVE[i+1][0]) {
      const t = (raw - CURVE[i][0]) / (CURVE[i+1][0] - CURVE[i][0]);
      return Math.round(CURVE[i][1] + t * (CURVE[i+1][1] - CURVE[i][1]));
    }
  }
  return raw;
}
function midpoint(lonA, lonB) {
  let diff = Math.abs(lonA - lonB);
  let mid = (lonA + lonB) / 2;
  if (diff > 180) mid = (mid + 180) % 360;
  return ((mid % 360) + 360) % 360;
}
function clamp(v, lo, hi) { return Math.min(hi, Math.max(lo, v)); }
function rand360() { return Math.random() * 360; }

// ── 分數表 ─────────────────────────────────────
const ATTR_MARS = {Scorpio:92,Aries:88,Capricorn:75,Leo:72,Sagittarius:65,Gemini:58,Pisces:52,Aquarius:45,Libra:40,Virgo:28,Taurus:35,Cancer:25};
const ATTR_VEN  = {Libra:95,Taurus:88,Pisces:83,Leo:68,Gemini:60,Cancer:56,Sagittarius:55,Aquarius:48,Capricorn:38,Virgo:30,Aries:40,Scorpio:38};
const ATTR_MOO  = {Cancer:85,Taurus:82,Pisces:72,Leo:60,Libra:58,Scorpio:58,Sagittarius:50,Aries:52,Gemini:48,Aquarius:42,Capricorn:28,Virgo:22};
const STAB_MOO  = {Taurus:95,Cancer:85,Virgo:72,Pisces:55,Libra:52,Aquarius:45,Leo:40,Gemini:38,Sagittarius:28,Scorpio:32,Capricorn:25,Aries:18};
const STAB_SAT  = {Capricorn:95,Libra:90,Aquarius:80,Taurus:70,Virgo:62,Scorpio:60,Pisces:48,Gemini:42,Sagittarius:35,Leo:28,Cancer:20,Aries:15};
const STAB_SUN  = {Leo:85,Aries:78,Capricorn:75,Taurus:68,Cancer:65,Virgo:62,Scorpio:58,Pisces:46,Sagittarius:42,Gemini:38,Aquarius:28,Libra:22};
const COMM_MER  = {Gemini:96,Virgo:90,Aquarius:72,Libra:68,Aries:62,Leo:58,Scorpio:52,Cancer:48,Taurus:42,Capricorn:38,Pisces:22,Sagittarius:18};
const COMM_ASC  = {Gemini:92,Libra:84,Aquarius:78,Leo:66,Sagittarius:62,Aries:56,Scorpio:48,Cancer:42,Pisces:42,Virgo:35,Taurus:30,Capricorn:20};
const COMM_SUN  = {Gemini:90,Leo:82,Aries:76,Aquarius:72,Sagittarius:68,Scorpio:55,Virgo:50,Cancer:44,Taurus:38,Pisces:38,Libra:32,Capricorn:28};
const TRST_MOO  = {Cancer:95,Taurus:90,Pisces:65,Virgo:62,Libra:55,Leo:50,Scorpio:48,Aquarius:42,Gemini:36,Capricorn:25,Sagittarius:30,Aries:18};
const TRST_SAT  = {Capricorn:95,Libra:88,Aquarius:80,Taurus:68,Virgo:62,Scorpio:58,Pisces:48,Gemini:42,Sagittarius:35,Leo:28,Cancer:20,Aries:15};
const TRST_SUN  = {Leo:90,Taurus:88,Capricorn:85,Scorpio:82,Cancer:75,Aries:70,Virgo:65,Sagittarius:52,Pisces:46,Aquarius:35,Gemini:31,Libra:27};
const GROW_JUP  = {Sagittarius:95,Cancer:88,Pisces:84,Aries:70,Leo:66,Aquarius:62,Libra:55,Scorpio:50,Taurus:48,Capricorn:20,Gemini:18,Virgo:15};
const GROW_SUN  = {Sagittarius:90,Aries:84,Leo:80,Gemini:68,Aquarius:55,Scorpio:55,Pisces:50,Cancer:48,Capricorn:45,Taurus:38,Libra:28,Virgo:25};
const GROW_ASC  = {Sagittarius:90,Aries:82,Aquarius:78,Gemini:72,Leo:65,Libra:55,Scorpio:52,Pisces:45,Cancer:42,Capricorn:38,Taurus:28,Virgo:18};

function ss(table, sign) { return table[sign.en] ?? 50; }

// ── 相位計算 ──────────────────────────────────
const ASPECT_DEFS = [
  {name:'conjunction',target:0,orb:8},{name:'sextile',target:60,orb:6},
  {name:'square',target:90,orb:8},{name:'trine',target:120,orb:8},
  {name:'opposition',target:180,orb:8}
];
function getAspect(lon1, lon2) {
  const diff = Math.abs(lon1 - lon2) % 360;
  const angle = diff > 180 ? 360 - diff : diff;
  for (const asp of ASPECT_DEFS) {
    const dist = Math.abs(angle - asp.target);
    if (dist <= asp.orb) return {name:asp.name, dist};
  }
  return null;
}
function orbStrength(dist) {
  if (dist <= 3) return 1.0;
  if (dist <= 6) return 0.6;
  return 0.3;
}
function applyAspect(lon1, lon2, mults) {
  if (lon1 == null || lon2 == null) return 1.0;
  const asp = getAspect(lon1, lon2);
  if (!asp) return 1.0;
  const full = mults[asp.name] ?? 1.0;
  return 1.0 + (full - 1.0) * orbStrength(asp.dist);
}

const AM_VENUS_MARS = {conjunction:1.10,trine:1.07,sextile:1.04,opposition:0.99,square:0.94};
const AM_MOON_VENUS = {conjunction:1.05,trine:1.03,sextile:1.02,opposition:0.99,square:0.97};
const AS_MOON_SAT   = {conjunction:1.09,trine:1.07,sextile:1.04,opposition:0.94,square:0.91};
const AS_SUN_SAT    = {conjunction:1.06,trine:1.04,sextile:1.02,opposition:0.96,square:0.95};
const AC_MER_ASC    = {conjunction:1.08,trine:1.05,sextile:1.03,opposition:0.95,square:0.92};
const AC_MER_SUN    = {conjunction:1.06,trine:1.04,sextile:1.02,opposition:0.97,square:0.96};
const AT_SUN_MOO    = {conjunction:1.09,trine:1.07,sextile:1.04,opposition:0.96,square:0.93};
const AT_MOO_SAT    = {conjunction:1.07,trine:1.05,sextile:1.03,opposition:0.93,square:0.91};
const AG_JUP_SUN    = {conjunction:1.10,trine:1.08,sextile:1.05,opposition:0.97,square:0.93};
const AG_JUP_ASC    = {conjunction:1.06,trine:1.04,sextile:1.02,opposition:0.98,square:0.95};
const AG_SUN_ASC    = {conjunction:1.06,trine:1.04,sextile:1.02,opposition:0.97,square:0.94};
const AS_MOO_SUN    = {conjunction:1.07,trine:1.05,sextile:1.03,opposition:0.96,square:0.93};
const AT_SUN_SAT    = {conjunction:1.07,trine:1.05,sextile:1.03,opposition:0.96,square:0.93};

const ELEM_FULL = {
  Fire: {attr:1.03,stab:0.97,comm:1.01,trst:0.98,grow:1.02},
  Earth:{attr:1.00,stab:1.03,comm:0.98,trst:1.01,grow:0.97},
  Air:  {attr:1.01,stab:1.00,comm:1.03,trst:0.97,grow:1.01},
  Water:{attr:1.01,stab:1.01,comm:0.97,trst:1.03,grow:0.98}
};

// ── 單次模擬 ───────────────────────────────────
function simulate() {
  // 隨機產生兩人各8個天體的黃道度數
  const planetsA = {Sun:rand360(),Moon:rand360(),Mercury:rand360(),Venus:rand360(),Mars:rand360(),Jupiter:rand360(),Saturn:rand360(),Asc:rand360()};
  const planetsB = {Sun:rand360(),Moon:rand360(),Mercury:rand360(),Venus:rand360(),Mars:rand360(),Jupiter:rand360(),Saturn:rand360(),Asc:rand360()};

  // 合盤中點
  const L = {};   // 黃道度數
  const S = {};   // 星座物件
  for (const k of Object.keys(planetsA)) {
    L[k] = midpoint(planetsA[k], planetsB[k]);
    S[k] = lonToSign(L[k]);
  }

  // ── L1 基礎分 ──
  const base_attr = clamp(ss(ATTR_VEN,S.Venus)*0.50 + ss(ATTR_MARS,S.Mars)*0.50, 0, 100);
  const base_stab = clamp(ss(STAB_MOO,S.Moon)*0.40 + ss(STAB_SAT,S.Saturn)*0.40 + ss(STAB_SUN,S.Sun)*0.20, 0, 100);
  const base_comm = clamp(ss(COMM_MER,S.Mercury)*0.60 + ss(COMM_ASC,S.Asc)*0.40, 0, 100);
  const base_trst = clamp(ss(TRST_MOO,S.Moon)*0.35 + ss(TRST_SUN,S.Sun)*0.40 + ss(TRST_SAT,S.Saturn)*0.25, 0, 100);
  const base_grow = clamp(ss(GROW_JUP,S.Jupiter)*0.45 + ss(GROW_SUN,S.Sun)*0.35 + ss(GROW_ASC,S.Asc)*0.20, 0, 100);

  // ── L2 相位倍率 ──
  const asp_attr = clamp(applyAspect(L.Venus,L.Mars,AM_VENUS_MARS)*applyAspect(L.Moon,L.Venus,AM_MOON_VENUS), 0.82, 1.18);
  const asp_stab = clamp(applyAspect(L.Moon,L.Saturn,AS_MOON_SAT)*applyAspect(L.Sun,L.Saturn,AS_SUN_SAT)*applyAspect(L.Moon,L.Sun,AS_MOO_SUN), 0.75, 1.25);
  const asp_comm = clamp(applyAspect(L.Mercury,L.Asc,AC_MER_ASC)*applyAspect(L.Mercury,L.Sun,AC_MER_SUN), 0.82, 1.18);
  const asp_trst = clamp(applyAspect(L.Sun,L.Moon,AT_SUN_MOO)*applyAspect(L.Moon,L.Saturn,AT_MOO_SAT)*applyAspect(L.Sun,L.Saturn,AT_SUN_SAT), 0.75, 1.25);
  const asp_grow = clamp(applyAspect(L.Jupiter,L.Sun,AG_JUP_SUN)*applyAspect(L.Jupiter,L.Asc,AG_JUP_ASC)*applyAspect(L.Sun,L.Asc,AG_SUN_ASC), 0.75, 1.25);

  // ── L3 元素倍率 ──
  const elemCount = {Fire:0,Earth:0,Air:0,Water:0};
  for (const k of ['Sun','Moon','Mercury','Venus','Mars','Jupiter','Saturn','Asc']) {
    const el = S[k]?.el; if (el) elemCount[el]++;
  }
  const et = 8;
  const domEntry = Object.entries(elemCount).sort((a,b)=>b[1]-a[1])[0];
  const domEl = domEntry[0];
  const elemStrength = clamp((domEntry[1]/et - 0.30) / 0.20, 0, 1);
  function elemMult(dim) {
    const full = ELEM_FULL[domEl]?.[dim] ?? 1.0;
    return 1.0 + (full - 1.0) * elemStrength;
  }

  // ── 三層合一 ──
  const attraction    = Math.round(clamp(base_attr * asp_attr * elemMult('attr'), 0, 100));
  const stability     = Math.round(clamp(base_stab * asp_stab * elemMult('stab'), 0, 100));
  const communication = Math.round(clamp(base_comm * asp_comm * elemMult('comm'), 0, 100));
  const trust         = Math.round(clamp(base_trst * asp_trst * elemMult('trst'), 0, 100));
  const growth        = Math.round(clamp(base_grow * asp_grow * elemMult('grow'),  0, 100));

  const rawCompat = (attraction + stability + communication + trust + growth) * 0.20;
  const compatScore    = Math.round(clamp(rawCompat, 20, 95));
  const compatStretched = curveScore(rawCompat);

  return {compatScore, compatStretched, attraction, stability, communication, trust, growth};
}

// ── 跑 N 次 ────────────────────────────────────
console.log(`模擬 ${N.toLocaleString()} 次合盤...`);
const scores = [];
const scoresS = []; // stretched
const dims = {attraction:[],stability:[],communication:[],trust:[],growth:[]};

for (let i = 0; i < N; i++) {
  const r = simulate();
  scores.push(r.compatScore);
  scoresS.push(r.compatStretched);
  dims.attraction.push(r.attraction);
  dims.stability.push(r.stability);
  dims.communication.push(r.communication);
  dims.trust.push(r.trust);
  dims.growth.push(r.growth);
}

// ── 統計 ───────────────────────────────────────
function stats(arr) {
  const n = arr.length;
  const sorted = [...arr].sort((a,b)=>a-b);
  const mean = arr.reduce((s,x)=>s+x,0)/n;
  const variance = arr.reduce((s,x)=>s+(x-mean)**2,0)/n;
  const std = Math.sqrt(variance);
  return {
    mean:mean.toFixed(1), std:std.toFixed(1),
    min:sorted[0], max:sorted[n-1],
    p5:sorted[Math.floor(n*0.05)], p10:sorted[Math.floor(n*0.10)],
    p25:sorted[Math.floor(n*0.25)], p50:sorted[Math.floor(n*0.50)],
    p75:sorted[Math.floor(n*0.75)], p90:sorted[Math.floor(n*0.90)],
    p95:sorted[Math.floor(n*0.95)]
  };
}

function histogram(arr, buckets) {
  const counts = new Array(buckets.length-1).fill(0);
  for (const v of arr) {
    for (let i=0; i<buckets.length-1; i++) {
      if (v >= buckets[i] && v < buckets[i+1]) { counts[i]++; break; }
      if (i === buckets.length-2 && v >= buckets[i+1]) counts[i]++;  // 最後一格含上界
    }
  }
  return counts;
}

const BUCKETS = [20,25,30,35,40,45,50,55,60,65,70,75,80,85,90,96];
// 你的目標比例（對應 BUCKETS 各區間）
const TARGET_PCT = [1, 2, 3, 5, 7, 8, 10, 11, 12, 12, 11, 9, 5, 3, 1];

const hist  = histogram(scores,  BUCKETS);
const histS = histogram(scoresS, BUCKETS);
const n = scores.length;

function printHist(label, h, showTarget) {
  console.log(`\n══ ${label} ${'═'.repeat(Math.max(0,36-label.length))}`);
  console.log('區間  │ 目標  │ 實際  │ 長條圖');
  console.log('──────┼───────┼───────┼' + '─'.repeat(35));
  for (let i=0; i<h.length; i++) {
    const lo = BUCKETS[i], hi = BUCKETS[i+1]-1;
    const pct = (h[i]/n*100).toFixed(1);
    const tgt = showTarget ? String(TARGET_PCT[i]+'%').padStart(5) : '  —  ';
    const bar = '█'.repeat(Math.round(h[i]/n*100));
    const label2 = `${String(lo).padStart(2)}–${String(hi).padStart(2)}`;
    console.log(`${label2}  │ ${tgt} │ ${pct.padStart(5)}% │ ${bar}`);
  }
}

printHist('現在版（未拉伸）', hist, true);
printHist('曲線版（分段插值）', histS, true);

function printStats(label, arr) {
  const st = stats(arr);
  const pctFn = (thr, dir) => {
    const cnt = dir==='>' ? arr.filter(s=>s>=thr).length : arr.filter(s=>s<=thr).length;
    return (cnt/arr.length*100).toFixed(2);
  };
  console.log(`\n── ${label} stats ────────────────`);
  console.log(`mean=${st.mean}  std=${st.std}  min=${st.min}  max=${st.max}`);
  console.log(`P5=${st.p5}  P25=${st.p25}  P50=${st.p50}  P75=${st.p75}  P95=${st.p95}`);
  console.log(`≥85: ${pctFn(85,'>')}%  ≥90: ${pctFn(90,'>')}%  ≤35: ${pctFn(35,'<')}%  ≤30: ${pctFn(30,'<')}%  ≤25: ${pctFn(25,'<')}%`);
}

printStats('現在版', scores);
printStats('拉伸版', scoresS);

console.log('\n══════════════════════════════════');
console.log('    各維度平均分');
console.log('══════════════════════════════════');
for (const [k,arr] of Object.entries(dims)) {
  const s = stats(arr);
  console.log(`${k.padEnd(15)}: mean=${s.mean}  std=${s.std}  P5=${s.p5}  P95=${s.p95}`);
}