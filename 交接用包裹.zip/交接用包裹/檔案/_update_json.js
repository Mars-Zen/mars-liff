const fs = require('fs');

const jsonPath = 'c:\\Users\\USER\\OneDrive\\桌面\\全部\\API_Composite.json';
const jsPath   = 'c:\\Users\\USER\\OneDrive\\桌面\\全部\\_calc_composite_new.js';

const rawJson  = fs.readFileSync(jsonPath, 'utf8').replace(/^﻿/, '');
const workflow = JSON.parse(rawJson);
const newCode  = fs.readFileSync(jsPath, 'utf8');

let updated = false;
for (const node of workflow.nodes) {
  if (node.id === '21033ed5-bbce-40a1-be5e-43ee9128944c') {
    node.parameters.jsCode = newCode;
    updated = true;
    console.log('Updated Calc_Composite. New code length:', newCode.length);
    break;
  }
}

if (!updated) {
  console.error('Node not found!');
  process.exit(1);
}

fs.writeFileSync(jsonPath, JSON.stringify(workflow, null, 2), 'utf8');
console.log('Written. File size:', fs.statSync(jsonPath).size, 'bytes');

// Verify
const check = JSON.parse(fs.readFileSync(jsonPath, 'utf8'));
const calcNode = check.nodes.find(n => n.id === '21033ed5-bbce-40a1-be5e-43ee9128944c');
console.log('Verify code length:', calcNode.parameters.jsCode.length);
console.log('Has ATTR_MARS:', calcNode.parameters.jsCode.includes('ATTR_MARS'));
console.log('Has elemStrength:', calcNode.parameters.jsCode.includes('elemStrength'));
console.log('Has asp_attr:', calcNode.parameters.jsCode.includes('asp_attr'));
console.log('Node count:', check.nodes.length);