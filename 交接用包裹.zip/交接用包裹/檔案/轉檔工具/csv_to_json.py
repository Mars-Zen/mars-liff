import os
import csv
import json

CSV_FOLDER  = r"C:\Users\USER\OneDrive\桌面\全部\資料表"
JSON_FOLDER = r"C:\Users\USER\OneDrive\桌面\全部\資料表_json"

os.makedirs(JSON_FOLDER, exist_ok=True)

for filename in os.listdir(CSV_FOLDER):
    if not filename.endswith(".csv"):
        continue

    csv_path  = os.path.join(CSV_FOLDER, filename)
    json_name = filename.replace(".csv", ".json")
    json_path = os.path.join(JSON_FOLDER, json_name)

    with open(csv_path, encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2)

    print(f"[OK] {filename} → {json_name}（{len(rows)} 筆）")

print("\n完成，JSON 檔案存放於：", JSON_FOLDER)